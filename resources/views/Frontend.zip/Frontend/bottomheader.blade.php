{{-- <div class="bottom-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <div class="logo">
                    <img src="{{ asset('images/logo.png') }}" alt="">
                </div>
            </div>
            <div class="col-md-7">
                <div class="menu">
                    <ul class="nav navbar-nav navbar-center ">
                        <li><a href="#">about us</a></li>
                        <li><a href="#">what we do</a></li>
                        <li><a href="#">chairman's section</a></li>
                        <li><a href="#">Total Accounting</a></li>
                    </ul>
                    <div class="col-md-2 donate">
                        <span><i class="far fa-heart"></i></span>
                        <a href="#">Donate Now Me</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> --}}
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="navigation">
        <div class="container" >
            <div class="col-md-12" style="padding-left: 0px;" >
                <div class="col-md-3" id="headermenu" >
                    <div class="navbar-brand hidden-sm hidden-xs ">
                        <a href="index.html"><img style="height: 55px;" src="images/Logo_new.png" class="img-responsive" alt=""> </a>
                    </div>
                </div>
            <div class="col-md-7 " style="padding-top:25px; padding-left:0px;">
                <div class="col-md-12">
                    <div id="navbar">
                        <nav class="" role="navigation">
                            <!-- .navbar-collapse -->
                            <div class="collapse navbar-collapse" id="navbar-collapse-1">
                                <ul class="nav navbar-nav">
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">About Us <b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="mission_vision.html">Misson & Vision</a></li>
                                            <li><a href="executive_committee.html">Executive Committee </a></li>
                                            <li><a href="general_body.html"> General Body</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">What We Do</a></li>
                                    <li><a href="#">Chairman’s Section</a></li>
                                    <li><a href="#">Total Accounting</a></li>
                                </ul>
                            </div>
                        <!-- /.navbar-collapse -->
                        </nav>
                    </div>
                </div>
            </div>
            <div class="Donate_now col-md-2">
                <span class="glyphicon glyphicon-heart" style="font-size:16px;"> </span>Donate Now Hello
            </div>
            </div>
        </div>
    </div>
</nav>
