<div class="row chose_type_of_donate" style="padding-left:30px;padding-top: 25px;">
    <div>Are You a Existing User</div>
    <div style="margin-left:130px">
        <label class="radio-inline">
            <input type="radio" name="user" id="login" checked>
            <span style="margin-left: 20px;">Yes</span>
        </label>
        <label class="radio-inline" style="margin-left:50px">
            <input type="radio" name="user" id="registration">
            <span style="margin-left: 20px;">No</span>
        </label>
    </div>
</div>
